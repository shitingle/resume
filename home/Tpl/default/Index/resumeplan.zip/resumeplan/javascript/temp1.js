$(".module-title").mouseover(function  () {
	$(".toolbar").show();
})

$(".module-title").mouseleave(function  () {
	$(".toolbar").hide();
})
$(".base-info .toolbar a").click(function  () {
	$(".base-info").remove();
})


    $( "#sortable" ).sortable({
      revert: true
    });
    $( "#draggable" ).draggable({
      connectToSortable: "#sortable",
      helper: "clone",
      revert: "invalid"
    });
    $( "ul, li" ).disableSelection();

